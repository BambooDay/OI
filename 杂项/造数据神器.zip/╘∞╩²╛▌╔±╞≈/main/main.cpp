#include <bits/stdc++.h>
#include <windows.h>
using namespace std;

const int st = 1;
const int ed = 10;
const string NAME = "data//Data_";
string s;

string str(int x) {
	string res = "";
	while (x) {
		res = (char)(x % 10 + '0') + res;
		x /= 10;
	}
	return NAME + res;
}

int main() {
	for (int i = st; i <= ed; ++i) {
		s = "gen.exe > " + str(i) + ".in";
		system(s.c_str());
		s = "std.exe < " + str(i) + ".in > " + str(i) + ".out";
		system(s.c_str());
		Sleep(1000);
		printf("Successful %d\n", i);
	}
	return 0;
}
